---
title: "Science Quiz for Students: Fun Questions for All Ages"
description: "Engaging science quiz questions ideal for students — covering biology, chemistry, physics and earth science."
pubDate: 2025-02-02
---

Science quizzes are a brilliant way for students to revise and discover new facts. Below we share question ideas teachers love.

## Topics covered

- Biology: cells, ecosystems, the human body
- Chemistry: elements, reactions, the periodic table
- Physics: forces, energy, motion
- Earth & space: planets, weather, geology

[Play the Science & Nature quiz now →](/quiz/science-nature)
