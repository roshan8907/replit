export interface Category {
  slug: string;
  name: string;
  icon: string;
  description: string;
  image: string; // unsplash url
  openTdbId: number;
}

export const categories: Category[] = [
  { slug: 'general-knowledge', name: 'General Knowledge', icon: '🧠', description: 'A bit of everything — perfect warm-up trivia.', image: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=800&q=70', openTdbId: 9 },
  { slug: 'entertainment', name: 'Entertainment', icon: '🎬', description: 'Movies, music, TV and pop culture.', image: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&q=70', openTdbId: 11 },
  { slug: 'history', name: 'History', icon: '🏺', description: 'From ancient civilizations to modern events.', image: 'https://images.unsplash.com/photo-1564399579883-451a5d44ec08?w=800&q=70', openTdbId: 23 },
  { slug: 'geography', name: 'Geography', icon: '🌍', description: 'Countries, capitals and landmarks.', image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=70', openTdbId: 22 },
  { slug: 'science-nature', name: 'Science & Nature', icon: '🔬', description: 'Biology, chemistry, physics and nature.', image: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=800&q=70', openTdbId: 17 },
  { slug: 'food-drink', name: 'Food & Drink', icon: '🍽️', description: 'Cuisine, ingredients and culinary trivia.', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&q=70', openTdbId: 0 },
  { slug: 'sports', name: 'Sports', icon: '⚽', description: 'Athletes, records and global games.', image: 'https://images.unsplash.com/photo-1521412644187-c49fa049e84d?w=800&q=70', openTdbId: 21 },
  { slug: 'technology', name: 'Technology', icon: '💻', description: 'Computers, gadgets and the digital world.', image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=70', openTdbId: 18 },
];

export const getCategory = (slug: string) => categories.find((c) => c.slug === slug);
