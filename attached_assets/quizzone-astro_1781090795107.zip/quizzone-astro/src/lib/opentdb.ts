import type { Question } from '@/data/questions';

export const USE_OPENTDB = false;

const decode = (s: string) => {
  if (typeof window === 'undefined') return s;
  const el = document.createElement('textarea');
  el.innerHTML = s;
  return el.value;
};

export async function fetchOpenTdbQuestions(categoryId: number, amount = 10): Promise<Question[]> {
  const url = `https://opentdb.com/api.php?amount=${amount}&type=multiple${categoryId ? `&category=${categoryId}` : ''}`;
  const res = await fetch(url);
  const data = (await res.json()) as { results: any[] };
  return data.results.map((r) => {
    const choices = [decode(r.correct_answer), ...r.incorrect_answers.map(decode)];
    for (let i = choices.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [choices[i], choices[j]] = [choices[j], choices[i]];
    }
    return {
      question: decode(r.question),
      choices,
      answer: choices.indexOf(decode(r.correct_answer)),
    };
  });
}
