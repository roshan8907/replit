# QuizZone (Astro)

Fast, SEO-friendly trivia quiz website built with **Astro + TypeScript + Tailwind CSS**.

## Run on Replit
1. Create a new Replit, choose **Node.js**.
2. Upload all these files (drag & drop the unzipped folder).
3. Click **Run** — Replit will install dependencies and start dev on port 3000.

## Run locally
```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # static site → ./dist
npm run preview
```

## Features
- 8 trivia categories, 10 questions each (`src/data/questions.ts`)
- Per-question 20s timer, correct/wrong Web Audio sounds
- Astro Content Collections blog (`src/content/posts`)
- SEO: per-page meta, canonical, Open Graph, JSON-LD, sitemap, robots.txt
- Mobile-first responsive layout, yellow + navy "trivia" theme
- Optional Open Trivia DB live API (`src/lib/opentdb.ts`, flip `USE_OPENTDB`)
- AdSense-ready ad slots (`src/components/AdSlot.astro`)

## Structure
```
src/
  components/  Header, Footer, CategoryCard, AdSlot
  content/     Blog posts (Markdown)
  data/        categories.ts, questions.ts
  layouts/     Base.astro (SEO + shell)
  lib/         sounds.ts, opentdb.ts
  pages/       index, categories, quiz/[category], blog, about, contact, privacy, terms
  styles/      global.css (Tailwind)
public/        robots.txt, favicon.svg
```
